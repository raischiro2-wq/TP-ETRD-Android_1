# Twilight Princess Arabic — Android/GameCube EUR port

Dusklight 2.0.2 native mod project for the GameCube EUR release.

- Original Arabic mod: **The Renewed Dream** (الحلم المتجدد)
- Android/GameCube EUR port: **RaisChiro**
- Includes the original ETRD asset overlays.
- Recreates the original native `dMeter2Draw_c::drawPikari` RTL correction recovered from the supplied Windows DLL.

The final distributable is a `.dusk` bundle. The included GitHub Actions workflow builds Android `arm64-v8a` and merges the platform bundles.
