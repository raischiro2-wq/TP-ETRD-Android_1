#include <cstddef>
#include <cstdint>

#include "mods/service.hpp"
#include "mods/svc/hook.hpp"
#include "mods/svc/hook.h"
#include "mods/svc/log.h"

#include "d/d_meter2_draw.h"
#include "d/d_msg_object.h"

DEFINE_MOD();

IMPORT_SERVICE(LogService, svc_log);
IMPORT_SERVICE(HookService, svc_hook);

// The original ETRD Windows DLL hooks dMeter2Draw_c::drawPikari.
// It mirrors the Pikari effect's X coordinate inside the message screen so
// the yellow glow follows RTL/reversed dialogue text instead of remaining
// on the vanilla left side.
DEFINE_HOOK(
    static_cast<void (dMeter2Draw_c::*)(
        f32, f32, f32*, f32,
        JUtility::TColor, JUtility::TColor,
        JUtility::TColor, JUtility::TColor,
        f32, u8
    )>(&dMeter2Draw_c::drawPikari),
    DrawPikari);

static HookAction on_draw_pikari_pre(ModContext*, void* args, void*, void*) {
    // arg 0 = this. The original DLL changes the first float argument.
    float& x = mods::arg_ref<float>(args, 1);

    // Preserve the original DLL's screen-space calculation. We deliberately
    // use offsets here because the original binary did the same through the
    // dMsgScrnBase_c layout and this keeps the hook independent of private
    // field names.
    dMsgScrnBase_c* screen = dMsgObject_c::getScrnDrawPtr();
    if (screen == nullptr) {
        return HOOK_CONTINUE;
    }

    auto* bytes = reinterpret_cast<std::byte*>(screen);
    const float left = *reinterpret_cast<float*>(bytes + 0xBC);
    const float width = *reinterpret_cast<float*>(bytes + 0xCC);

    if (width <= 0.0f) {
        return HOOK_CONTINUE;
    }

    const float relative = x - left;
    if (relative < 0.0f || relative > width) {
        return HOOK_CONTINUE;
    }

    // Exact transformation recovered from the original ETRD.dll:
    // x' = left + (width - (x - left))
    x = left + width - relative;
    return HOOK_CONTINUE;
}

extern "C" {
MOD_EXPORT ModResult mod_initialize(ModError* error) {
    ModResult result = mods::hook::add_pre<DrawPikari>(on_draw_pikari_pre);
    if (result != MOD_OK) {
        return mods::set_error(error, result, "failed to install ETRD drawPikari hook");
    }

    svc_log->info(mod_ctx, "ETRD 1.0.2 initialized (Android/GameCube EUR Pikari RTL fix)");
    return MOD_OK;
}

MOD_EXPORT ModResult mod_update(ModError*) {
    return MOD_OK;
}

MOD_EXPORT ModResult mod_shutdown(ModError*) {
    return MOD_OK;
}
}
